<?php
// GOD OF SERVER SNIPPETS: PHP EDITION
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/Storage.php';

$storage = new Storage(DATA_DIR);

$requestUri = $_SERVER['REQUEST_URI'];
$scriptName = $_SERVER['SCRIPT_NAME'];
$basePath = rtrim(dirname($scriptName), '/\\');
$uri = parse_url($requestUri, PHP_URL_PATH);

if ($basePath && strpos($uri, $basePath) === 0) {
    $uri = substr($uri, strlen($basePath));
}
if (empty($uri)) {
    $uri = '/';
}

$method = $_SERVER['REQUEST_METHOD'];

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');

if (!function_exists('str_starts_with')) {
    function str_starts_with($haystack, $needle) {
        return strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}

// Sadboy API responses
if (str_starts_with($uri, '/api/')) {
    header('Content-Type: application/json');
    
    if ($uri === '/api/auth/login' && $method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $username = isset($input['username']) ? $input['username'] : '';
        $password = isset($input['password']) ? $input['password'] : '';
        
        if ($username === ADMIN_USERNAME && verify_password($password)) {
            $_SESSION['user_id'] = 'admin';
            $_SESSION['username'] = ADMIN_USERNAME;
            $_SESSION['is_admin'] = true;
            json_response(array('success' => true, 'username' => ADMIN_USERNAME));
        }
        json_response(array('error' => 'Invalid credentials'), 401);
    }
    
    if ($uri === '/api/auth/logout' && $method === 'POST') {
        session_destroy();
        json_response(array('success' => true));
    }
    
    if ($uri === '/api/user') {
        if (is_logged_in()) {
            json_response(array('username' => $_SESSION['username'], 'is_admin' => true));
        }
        json_response(null);
    }
    
    if ($uri === '/api/snippets' && $method === 'GET') {
        if (is_logged_in()) {
            json_response($storage->getAllSnippets());
        }
        json_response($storage->getPublicSnippets());
    }
    
    if ($uri === '/api/snippets' && $method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $snippet = $storage->createSnippet($input);
        json_response($snippet, 201);
    }
    
    if (preg_match('#^/api/snippets/(\d+)$#', $uri, $matches)) {
        $id = (int)$matches[1];
        
        if ($method === 'GET') {
            $snippet = $storage->getSnippet($id);
            if (!$snippet) {
                json_response(array('error' => 'Not found'), 404);
            }
            if (!$snippet['is_public'] && !is_logged_in()) {
                json_response(array('error' => 'Private snippet'), 403);
            }
            $storage->incrementViews($id);
            json_response($snippet);
        }
        
        if ($method === 'PUT' || $method === 'PATCH') {
            if (!is_logged_in()) {
                json_response(array('error' => 'Unauthorized'), 401);
            }
            $input = json_decode(file_get_contents('php://input'), true);
            $snippet = $storage->updateSnippet($id, $input);
            if (!$snippet) {
                json_response(array('error' => 'Not found'), 404);
            }
            json_response($snippet);
        }
        
        if ($method === 'DELETE') {
            if (!is_logged_in()) {
                json_response(array('error' => 'Unauthorized'), 401);
            }
            if ($storage->deleteSnippet($id)) {
                json_response(array('success' => true));
            }
            json_response(array('error' => 'Not found'), 404);
        }
    }
    
    json_response(array('error' => 'Not found'), 404);
}

// Raw output
if (preg_match('#^/raw/(\d+)$#', $uri, $matches)) {
    $id = (int)$matches[1];
    $snippet = $storage->getSnippet($id);
    if (!$snippet) {
        http_response_code(404);
        echo 'Snippet not found';
        exit;
    }
    header('Content-Type: text/plain; charset=utf-8');
    echo $snippet['content'];
    exit;
}

// Page Routing
if ($uri === '/' || $uri === '') {
    $page = 'home';
} elseif ($uri === '/login') {
    $page = 'login';
} elseif ($uri === '/dashboard') {
    $page = 'dashboard';
} elseif ($uri === '/create') {
    $page = 'create';
} elseif (preg_match('#^/edit/(\d+)$#', $uri, $matches)) {
    $page = 'edit';
    $snippet_id = (int)$matches[1];
} elseif (preg_match('#^/s/(\d+)$#', $uri, $matches)) {
    $page = 'view';
    $snippet_id = (int)$matches[1];
} else {
    $page = '404';
}

$GLOBALS['base_path'] = $basePath;
include __DIR__ . '/templates/layout.php';
