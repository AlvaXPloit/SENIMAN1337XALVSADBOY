<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    
    if ($username === ADMIN_USERNAME && verify_password($password)) {
        $_SESSION['user_id'] = 'admin';
        $_SESSION['username'] = ADMIN_USERNAME;
        $_SESSION['is_admin'] = true;
        redirect(base_url('/dashboard'));
    }
    $error = 'Invalid credentials';
}
?>

<div class="max-w-md mx-auto">
    <div class="card rounded-lg p-8">
        <h1 class="text-2xl font-bold mb-6 text-center">Admin Login</h1>
        
        <?php if (isset($error)): ?>
            <div class="bg-red-500/20 border border-red-500 text-red-400 px-4 py-2 rounded mb-4">
                <?php echo h($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" class="space-y-4">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            
            <div>
                <label class="block text-sm text-gray-400 mb-1">Username</label>
                <input type="text" name="username" required 
                    class="w-full bg-background border border-border rounded px-4 py-2 text-white focus:border-primary focus:outline-none">
            </div>
            
            <div>
                <label class="block text-sm text-gray-400 mb-1">Password</label>
                <input type="password" name="password" required 
                    class="w-full bg-background border border-border rounded px-4 py-2 text-white focus:border-primary focus:outline-none">
            </div>
            
            <button type="submit" class="w-full bg-primary text-white py-2 rounded hover:bg-purple-600 transition-colors">
                Login
            </button>
        </form>
    </div>
</div>
