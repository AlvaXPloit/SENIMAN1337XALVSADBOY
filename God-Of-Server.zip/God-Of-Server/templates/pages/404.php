<div class="text-center py-20">
    <h1 class="text-6xl font-bold text-gray-600 mb-4">404</h1>
    <h2 class="text-2xl font-semibold mb-2">GADA APA APA BAJINGAN</h2>
    <p class="text-gray-400 mb-8">KAU NYARI APA BAJINGAN?</p>
    <a href="<?php echo base_url('/'); ?>" class="bg-primary text-white px-6 py-2 rounded hover:bg-purple-600">
        Go Home
    </a>
</div>
