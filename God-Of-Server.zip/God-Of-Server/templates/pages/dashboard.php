<?php
if (!is_logged_in()) {
    redirect(base_url('/login'));
}

$snippets = $storage->getAllSnippets();
?>

<div class="max-w-6xl mx-auto">
    <div class="flex justify-between items-center mb-8">
        <h1 class="text-3xl font-bold">Dashboard</h1>
        <a href="<?php echo base_url('/create'); ?>" class="bg-primary text-white px-4 py-2 rounded hover:bg-purple-600">
            + New Snippet
        </a>
    </div>

    <?php if (empty($snippets)): ?>
        <div class="text-center text-gray-400 py-12">
            <p class="text-xl mb-4">No snippets yet</p>
            <a href="<?php echo base_url('/create'); ?>" class="text-primary hover:underline">Create your first snippet</a>
        </div>
    <?php else: ?>
        <div class="card rounded-lg overflow-hidden">
            <table class="w-full">
                <thead class="bg-background">
                    <tr>
                        <th class="text-left px-4 py-3 text-gray-400">Title</th>
                        <th class="text-left px-4 py-3 text-gray-400">Status</th>
                        <th class="text-left px-4 py-3 text-gray-400">Views</th>
                        <th class="text-left px-4 py-3 text-gray-400">Created</th>
                        <th class="text-right px-4 py-3 text-gray-400">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($snippets as $snippet): ?>
                        <tr class="border-t border-border hover:bg-background/50">
                            <td class="px-4 py-3">
                                <a href="<?php echo base_url('/s/' . $snippet['id']); ?>" class="text-white hover:text-primary">
                                    <?php echo h($snippet['title']); ?>
                                </a>
                            </td>
                            <td class="px-4 py-3">
                                <?php if ($snippet['is_public']): ?>
                                    <span class="text-green-400 text-sm">Public</span>
                                <?php else: ?>
                                    <span class="text-yellow-400 text-sm">Private</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3 text-gray-400"><?php echo $snippet['views']; ?></td>
                            <td class="px-4 py-3 text-gray-400"><?php echo date('M d, Y', strtotime($snippet['created_at'])); ?></td>
                            <td class="px-4 py-3 text-right">
                                <a href="<?php echo base_url('/edit/' . $snippet['id']); ?>" class="text-primary hover:underline mr-3">Edit</a>
                                <a href="<?php echo base_url('/raw/' . $snippet['id']); ?>" class="text-gray-400 hover:text-white mr-3">Raw</a>
                                <form action="<?php echo base_url('/api/snippets/' . $snippet['id']); ?>" method="POST" class="inline" 
                                    onsubmit="return confirm('Delete this snippet?')">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="text-red-400 hover:text-red-300">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
