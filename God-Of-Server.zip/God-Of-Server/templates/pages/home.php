<div class="max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold mb-8 text-center">Public Snippets</h1>
    
    <?php
    $snippets = $storage->getPublicSnippets();
    if (empty($snippets)):
    ?>
        <div class="text-center text-gray-400 py-12">
            <p class="text-xl mb-4">No public snippets yet</p>
            <?php if (is_logged_in()): ?>
                <a href="<?php echo base_url('/create'); ?>" class="text-primary hover:underline">Create your first snippet</a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="grid gap-4">
            <?php foreach ($snippets as $snippet): ?>
                <a href="<?php echo base_url('/s/' . $snippet['id']); ?>" class="card rounded-lg p-4 hover:border-primary transition-colors">
                    <div class="flex justify-between items-start mb-2">
                        <h2 class="text-lg font-semibold text-white"><?php echo h($snippet['title']); ?></h2>
                        <span class="text-xs text-gray-500"><?php echo $snippet['views']; ?> views</span>
                    </div>
                    <?php if (!empty($snippet['description'])): ?>
                        <p class="text-gray-400 text-sm mb-2"><?php echo h($snippet['description']); ?></p>
                    <?php endif; ?>
                    <?php if (!empty($snippet['tags'])): ?>
                        <div class="flex gap-2 flex-wrap">
                            <?php foreach ($snippet['tags'] as $tag): ?>
                                <span class="text-xs bg-primary/20 text-primary px-2 py-1 rounded"><?php echo h($tag); ?></span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
