<?php
if (!is_logged_in()) {
    redirect(base_url('/login'));
}

preg_match('#/edit/(\d+)#', $uri, $matches);
$id = isset($matches[1]) ? (int)$matches[1] : 0;
$snippet = $storage->getSnippet($id);

if (!$snippet) {
    $page = '404';
    include __DIR__ . '/404.php';
    return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $content = isset($_POST['content']) ? $_POST['content'] : '';
    $description = isset($_POST['description']) ? trim($_POST['description']) : '';
    $category = isset($_POST['category']) ? trim($_POST['category']) : '';
    $tagsInput = isset($_POST['tags']) ? trim($_POST['tags']) : '';
    $is_public = isset($_POST['is_public']);
    
    $tags = array();
    if (!empty($tagsInput)) {
        $tags = array_map('trim', explode(',', $tagsInput));
        $tags = array_filter($tags);
    }
    
    if (!empty($title) && !empty($content)) {
        $storage->updateSnippet($id, array(
            'title' => $title,
            'content' => $content,
            'description' => $description,
            'category' => $category,
            'tags' => $tags,
            'is_public' => $is_public
        ));
        redirect(base_url('/s/' . $id));
    }
    $error = 'Title and content are required';
}

$tagsStr = is_array($snippet['tags']) ? implode(', ', $snippet['tags']) : '';
?>

<div class="max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold mb-8">Edit Snippet</h1>
    
    <?php if (isset($error)): ?>
        <div class="bg-red-500/20 border border-red-500 text-red-400 px-4 py-2 rounded mb-4">
            <?php echo h($error); ?>
        </div>
    <?php endif; ?>
    
    <form method="POST" class="card rounded-lg p-6 space-y-4">
        <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
        
        <div>
            <label class="block text-sm text-gray-400 mb-1">Title *</label>
            <input type="text" name="title" required value="<?php echo h($snippet['title']); ?>"
                class="w-full bg-background border border-border rounded px-4 py-2 text-white focus:border-primary focus:outline-none">
        </div>
        
        <div>
            <label class="block text-sm text-gray-400 mb-1">Description</label>
            <input type="text" name="description" value="<?php echo h($snippet['description']); ?>"
                class="w-full bg-background border border-border rounded px-4 py-2 text-white focus:border-primary focus:outline-none">
        </div>
        
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm text-gray-400 mb-1">Category</label>
                <input type="text" name="category" value="<?php echo h($snippet['category']); ?>"
                    class="w-full bg-background border border-border rounded px-4 py-2 text-white focus:border-primary focus:outline-none">
            </div>
            <div>
                <label class="block text-sm text-gray-400 mb-1">Tags (comma separated)</label>
                <input type="text" name="tags" value="<?php echo h($tagsStr); ?>"
                    class="w-full bg-background border border-border rounded px-4 py-2 text-white focus:border-primary focus:outline-none">
            </div>
        </div>
        
        <div>
            <label class="block text-sm text-gray-400 mb-1">Content *</label>
            <textarea name="content" rows="15" required
                class="w-full bg-background border border-border rounded px-4 py-2 text-white font-mono text-sm focus:border-primary focus:outline-none"><?php echo h($snippet['content']); ?></textarea>
        </div>
        
        <div class="flex items-center gap-2">
            <input type="checkbox" name="is_public" id="is_public" <?php echo $snippet['is_public'] ? 'checked' : ''; ?> class="rounded">
            <label for="is_public" class="text-gray-300">Make this snippet public</label>
        </div>
        
        <div class="flex gap-4">
            <button type="submit" class="bg-primary text-white px-6 py-2 rounded hover:bg-purple-600">
                Save Changes
            </button>
            <a href="<?php echo base_url('/dashboard'); ?>" class="text-gray-400 hover:text-white px-4 py-2">
                Cancel
            </a>
        </div>
    </form>
</div>
