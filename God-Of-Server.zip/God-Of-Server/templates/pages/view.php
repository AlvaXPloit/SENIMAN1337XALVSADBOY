<?php
preg_match('#/s/(\d+)#', $uri, $matches);
$id = isset($matches[1]) ? (int)$matches[1] : 0;
$snippet = $storage->getSnippet($id);

if (!$snippet) {
    $page = '404';
    include __DIR__ . '/404.php';
    return;
}

if (!$snippet['is_public'] && !is_logged_in()) {
    $page = '404';
    include __DIR__ . '/404.php';
    return;
}

$storage->incrementViews($id);
?>

<div class="max-w-4xl mx-auto">
    <div class="mb-6">
        <div class="flex justify-between items-start mb-4">
            <h1 class="text-3xl font-bold"><?php echo h($snippet['title']); ?></h1>
            <div class="flex gap-2">
                <a href="<?php echo base_url('/raw/' . $id); ?>" class="text-gray-400 hover:text-white px-3 py-1 border border-border rounded text-sm">
                    Raw
                </a>
                <?php if (is_logged_in()): ?>
                    <a href="<?php echo base_url('/edit/' . $id); ?>" class="text-primary hover:underline px-3 py-1 border border-primary rounded text-sm">
                        Edit
                    </a>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if (!empty($snippet['description'])): ?>
            <p class="text-gray-400 mb-4"><?php echo h($snippet['description']); ?></p>
        <?php endif; ?>
        
        <div class="flex items-center gap-4 text-sm text-gray-500">
            <span><?php echo $snippet['views']; ?> views</span>
            <span>Created <?php echo date('M d, Y', strtotime($snippet['created_at'])); ?></span>
            <?php if (!$snippet['is_public']): ?>
                <span class="text-yellow-400">Private</span>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($snippet['tags'])): ?>
            <div class="flex gap-2 flex-wrap mt-4">
                <?php foreach ($snippet['tags'] as $tag): ?>
                    <span class="text-xs bg-primary/20 text-primary px-2 py-1 rounded"><?php echo h($tag); ?></span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="card rounded-lg overflow-hidden">
        <div class="bg-background px-4 py-2 border-b border-border flex justify-between items-center">
            <span class="text-sm text-gray-400"><?php echo h($snippet['category'] ? $snippet['category'] : 'Code'); ?></span>
            <button onclick="copyToClipboard()" class="text-sm text-primary hover:underline">Copy</button>
        </div>
        <pre class="p-4 overflow-x-auto"><code class="language-javascript"><?php echo h($snippet['content']); ?></code></pre>
    </div>
</div>

<script>
function copyToClipboard() {
    const content = <?php echo json_encode($snippet['content']); ?>;
    navigator.clipboard.writeText(content).then(function() {
        alert('Copied to clipboard!');
    });
}
</script>
