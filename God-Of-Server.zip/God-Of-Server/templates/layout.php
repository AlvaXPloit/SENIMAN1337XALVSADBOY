<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo h(SITE_NAME); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#ef4444',
                        background: '#0a0a0a',
                        card: '#111111',
                        border: '#262626'
                    }
                }
            }
        }
    </script>
    <style>
        @keyframes glitch {
            0% { transform: translate(0); }
            20% { transform: translate(-2px, 2px); }
            40% { transform: translate(-2px, -2px); }
            60% { transform: translate(2px, 2px); }
            80% { transform: translate(2px, -2px); }
            100% { transform: translate(0); }
        }
        .glitch:hover { animation: glitch 0.3s infinite; }
        body { background-color: #0a0a0a; color: #fafafa; font-family: monospace; }
        .sadboy-card { background: #111; border: 1px solid #222; position: relative; }
        .sadboy-card::before { content: ""; position: absolute; top: 0; left: 0; width: 100%; height: 2px; background: linear-gradient(90deg, transparent, #ef4444, transparent); }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <header class="border-b border-zinc-800 bg-black/50 backdrop-blur-md sticky top-0 z-50">
        <nav class="container mx-auto px-4 py-4 flex justify-between items-center">
            <a href="<?php echo base_url('/'); ?>" class="text-xl font-bold tracking-tighter glitch">
                <span class="text-red-500">GOD</span> OF SERVER SNIPPETS
            </a>
            <div class="flex items-center gap-6 text-sm uppercase font-bold">
                <?php if (is_logged_in()): ?>
                    <a href="<?php echo base_url('/dashboard'); ?>" class="hover:text-red-500 transition-colors">DASHBOARD</a>
                    <a href="<?php echo base_url('/create'); ?>" class="border border-red-500 px-3 py-1 hover:bg-red-500 transition-all">NEW_SNIP</a>
                    <form action="<?php echo base_url('/api/auth/logout'); ?>" method="POST" class="inline">
                        <button type="submit" class="text-zinc-500 hover:text-white transition-colors">LOGOUT</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo base_url('/login'); ?>" class="hover:text-red-500 transition-colors">LOGIN</a>
                <?php endif; ?>
            </div>
        </nav>
    </header>

    <main class="flex-1 container mx-auto px-4 py-8">
        <?php 
        $pageFile = __DIR__ . '/pages/' . $page . '.php';
        if (file_exists($pageFile)) {
            include $pageFile;
        } else {
            echo "Page not found: " . h($page);
        }
        ?>
    </main>

    <footer class="border-t border-zinc-900 py-8 text-center text-xs text-zinc-600 tracking-widest uppercase">
        <p>STAY SAD // <span class="text-red-900">GOD OF SERVER</span> // © <?php echo date('Y'); ?></p>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-javascript.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-php.min.js"></script>
</body>
</html>
