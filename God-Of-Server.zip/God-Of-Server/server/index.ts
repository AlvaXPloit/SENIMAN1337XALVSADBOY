import { spawn } from "child_process";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, "..");

console.log("GOD OF SERVER SNIPPETS: PHP ENGINE STARTING...");

const php = spawn("php", ["-S", "0.0.0.0:5000", "-t", ".", "router.php"], {
  stdio: "inherit",
  cwd: rootDir,
});

php.on("error", (err) => {
  console.error("CRITICAL: PHP process failed to start:", err);
});

php.on("close", (code) => {
  console.log(`PHP process exited with code ${code}`);
});
