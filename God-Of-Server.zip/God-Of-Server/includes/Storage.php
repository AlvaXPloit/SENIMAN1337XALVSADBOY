<?php
class Storage {
    private $dataDir;
    private $cache = [];
    
    public function __construct($dataDir) {
        $this->dataDir = $dataDir;
        if (!is_dir($dataDir)) {
            mkdir($dataDir, 0755, true);
        }
    }
    
    private function getFilePath($collection) {
        return $this->dataDir . '/' . $collection . '.json';
    }
    
    private function load($collection) {
        if (isset($this->cache[$collection])) {
            return $this->cache[$collection];
        }
        
        $file = $this->getFilePath($collection);
        if (!file_exists($file)) {
            return [];
        }
        
        $content = file_get_contents($file);
        $data = json_decode($content, true) ?? [];
        $this->cache[$collection] = $data;
        return $data;
    }
    
    private function save($collection, $data) {
        $file = $this->getFilePath($collection);
        $tempFile = $file . '.tmp';
        
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if (file_put_contents($tempFile, $json, LOCK_EX) === false) {
            return false;
        }
        
        if (!rename($tempFile, $file)) {
            unlink($tempFile);
            return false;
        }
        
        $this->cache[$collection] = $data;
        return true;
    }
    
    public function getAllSnippets() {
        $snippets = $this->load('snippets');
        usort($snippets, function($a, $b) {
            return strtotime($b['created_at']) - strtotime($a['created_at']);
        });
        return $snippets;
    }
    
    public function getPublicSnippets() {
        $snippets = $this->getAllSnippets();
        return array_values(array_filter($snippets, function($s) {
            return (isset($s['is_public']) ? $s['is_public'] : true) === true;
        }));
    }
    
    public function getSnippet($id) {
        $snippets = $this->load('snippets');
        foreach ($snippets as $snippet) {
            if ($snippet['id'] == $id) {
                return $snippet;
            }
        }
        return null;
    }
    
    public function createSnippet($data) {
        $snippets = $this->load('snippets');
        $maxId = 0;
        foreach ($snippets as $s) {
            if ($s['id'] > $maxId) $maxId = $s['id'];
        }
        
        $snippet = [
            'id' => $maxId + 1,
            'title' => $data['title'] ?? 'Untitled',
            'content' => $data['content'] ?? '',
            'description' => $data['description'] ?? null,
            'is_public' => isset($data['is_public']) ? (bool)$data['is_public'] : true,
            'views' => 0,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        $snippets[] = $snippet;
        $this->save('snippets', $snippets);
        return $snippet;
    }
    
    public function updateSnippet($id, $data) {
        $snippets = $this->load('snippets');
        foreach ($snippets as &$snippet) {
            if ($snippet['id'] == $id) {
                foreach ($data as $key => $value) {
                    $snippet[$key] = $value;
                }
                $snippet['updated_at'] = date('Y-m-d H:i:s');
                $this->save('snippets', $snippets);
                return $snippet;
            }
        }
        return null;
    }
    
    public function deleteSnippet($id) {
        $snippets = $this->load('snippets');
        $filtered = array_filter($snippets, function($s) use ($id) {
            return $s['id'] != $id;
        });
        if (count($filtered) === count($snippets)) {
            return false;
        }
        $this->save('snippets', array_values($filtered));
        return true;
    }
    
    public function incrementViews($id) {
        $snippets = $this->load('snippets');
        foreach ($snippets as &$snippet) {
            if ($snippet['id'] == $id) {
                $snippet['views'] = ($snippet['views'] ?? 0) + 1;
                $this->save('snippets', $snippets);
                return;
            }
        }
    }
}
