<?php
define('SITE_NAME', 'GOD OF SERVER SNIPPETS');
define('DATA_DIR', __DIR__ . '/../data');
define('ADMIN_USERNAME', 'GodOfServer');
define('ADMIN_PASSWORD', 'GodOfServerWasHere!');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf($token) {
    $stored = isset($_SESSION['csrf_token']) ? $_SESSION['csrf_token'] : '';
    return hash_equals($stored, $token);
}

function is_logged_in() {
    return isset($_SESSION['user_id']) && isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function h($text) {
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

function json_response($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function verify_password($password) {
    return $password === ADMIN_PASSWORD;
}

function base_url($path = '') {
    $base = isset($GLOBALS['base_path']) ? $GLOBALS['base_path'] : '';
    return $base . $path;
}
