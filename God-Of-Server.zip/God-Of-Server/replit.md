# replit.md

## Overview

This is a code snippets sharing platform. The application stores snippets and user data in JSON files and serves them via a PHP built-in web server. The project has a hybrid architecture: a Node.js/TypeScript build system and entry point that spawns a PHP server to handle HTTP requests. The application appears to be in early stages with minimal data (one sample snippet and no users).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Server Architecture
- **Runtime**: The server entry point is a TypeScript file (`server/index.ts`) that spawns a PHP built-in web server on port 5000.
- **PHP Server**: Uses PHP's built-in development server (`php -S`) with a `router.php` file (referenced but not present in the repo yet) as the request router. The document root is the project root (`.`).
- **Why this approach**: The project bridges Node.js tooling (TypeScript, esbuild, Vite) with PHP for the actual HTTP serving. This is unconventional — the Node process is essentially a wrapper that launches PHP.

### Build System
- **Client Build**: Uses Vite for frontend bundling.
- **Server Build**: Uses esbuild to bundle the server TypeScript code. Dependencies are split into an allowlist (bundled to reduce cold start syscalls) and externals (kept as external imports).
- **Build Script**: Located at `script/build.ts`, cleans the `dist` directory, builds client with Vite, then builds server with esbuild.

### Data Storage
- **Storage mechanism**: Flat JSON files stored in two locations:
  - `data/snippets.json` and `data/users.json` — likely the canonical data source
  - `public/data/snippets.json` and `public/data/users.json` — publicly accessible copies served by the web server
- **Schema** (inferred from JSON):
  - **Snippets**: `id`, `title`, `content`, `description`, `category`, `tags` (array), `is_public` (boolean), `views` (integer), `created_at`, `updated_at`
  - **Users**: Empty array, schema not yet defined
- **No database**: There is no SQL database currently. Data is persisted in JSON files. If a database is added later, the allowlist in the build script already includes `drizzle-orm`, `pg`, and `connect-pg-simple`, suggesting PostgreSQL with Drizzle ORM was planned.

### Important Missing Files
- `router.php` — Referenced in `server/index.ts` but not present. This is the PHP router that handles all incoming HTTP requests. It needs to be created.
- `package.json` — Referenced in the build script but not included. Contains dependency definitions.
- Vite config — Not present but needed for the client build.
- Frontend source files — No client-side code is present yet.

### Key Architectural Decisions
1. **PHP + Node.js hybrid**: Node.js handles the build pipeline and process management, while PHP handles HTTP serving. This means PHP must be available in the runtime environment.
2. **JSON file storage**: Simple flat-file storage instead of a database. Good for simplicity but doesn't scale and has concurrency issues with writes.
3. **Dual data directories**: Having `data/` and `public/data/` with the same content suggests `public/` is the web-accessible directory and `data/` may be for server-side operations.

## External Dependencies

### Build Tools
- **Vite** — Frontend bundler
- **esbuild** — Server-side TypeScript bundler

### Runtime Dependencies (from build allowlist, not all may be actively used)
- **express** — Web framework (listed in allowlist but PHP is currently serving)
- **drizzle-orm** / **drizzle-zod** — ORM and schema validation (prepared for future database integration)
- **pg** — PostgreSQL client (prepared for future use)
- **passport** / **passport-local** — Authentication
- **express-session** / **memorystore** / **connect-pg-simple** — Session management
- **jsonwebtoken** — JWT authentication
- **zod** / **zod-validation-error** — Schema validation
- **cors** — Cross-origin resource sharing
- **express-rate-limit** — Rate limiting
- **multer** — File upload handling
- **nanoid** / **uuid** — ID generation
- **nodemailer** — Email sending
- **openai** / **@google/generative-ai** — AI integrations
- **stripe** — Payment processing
- **axios** — HTTP client
- **ws** — WebSocket support
- **xlsx** — Spreadsheet handling
- **date-fns** — Date utilities

### Runtime Requirements
- **PHP** — Must be installed and available in PATH for the server to start
- **Node.js** — Required for the build system and server entry point