<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $target = basename($_FILES['file']['name']);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
        echo "✅ File berhasil diupload.";
    } else {
        echo "❌ Gagal upload.";
    }
}
?>
<!DOCTYPE html>
<html><body>
<h2>📤 Upload File</h2>
<form method="post" enctype="multipart/form-data">
    <input type="file" name="file" required><br><br>
    <button type="submit">Upload</button>
</form>
</body></html>
